using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LabyrinthNode
{
    public int rows;
    public int columns;

    public LabyrinthNode(int Rows, int Columns)
    {
        this.rows = Rows;
        this.columns = Columns;
    }
}
