
public class VisualNode
{
    public int NodeID;
    public VisualNode(int NodeID)
    {
        this.NodeID = NodeID;
    }
}
